#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>

#define MAX_R 31			//Maximum rows a maze file can have
#define MAX_C 61			//Maximum columns a maze file can have
#define LEVELS 3			//level1.txt, level2.txt, level3.txt
#define MAX_HINTS 3			//Hints allowed per level

#define WALL '#'
#define OPEN '.'
#define START 'S'
#define EXIT 'E'
#define PATH '*'			//Cell that is part of the current route
#define DEAD 'x'			//Cell that was tried and turned out to be a dead end

int rows = 0, cols = 0;			//Size of the maze that is currently loaded
int calls = 0, backtracks = 0;		//Statistics of the recursive solver

//------------------------------------------------------------------------------------------------------
//												FILE INPUT / OUTPUT
//------------------------------------------------------------------------------------------------------

/*
	Maze file format:
	Line 1 : rows cols
	Next lines : the maze, one row per line
	# = wall    . = open path    S = start    E = exit
*/
int load_maze(char* filename, char maze[][MAX_C], int* sr, int* sc, int* er, int* ec)
{
	FILE* fp = fopen(filename, "r");
	if (fp == NULL)
	{
		printf("\n\tError: could not open %s\n", filename);
		return 0;
	}

	if (fscanf(fp, "%d %d", &rows, &cols) != 2 || rows < 3 || cols < 3 || rows > MAX_R || cols > MAX_C)
	{
		printf("\n\tError: %s has an invalid size line.\n", filename);
		fclose(fp);
		return 0;
	}

	int i, j;
	int foundS = 0, foundE = 0;
	char line[MAX_C + 10];

	for (i = 0; i < rows; i++)
	{
		if (fscanf(fp, "%s", line) != 1 || (int)strlen(line) != cols)
		{
			printf("\n\tError: row %d of %s is missing or has the wrong length.\n", i + 1, filename);
			fclose(fp);
			return 0;
		}

		for (j = 0; j < cols; j++)
		{
			maze[i][j] = line[j];

			if (line[j] == START)
			{
				*sr = i;
				*sc = j;
				foundS = 1;
			}
			else if (line[j] == EXIT)
			{
				*er = i;
				*ec = j;
				foundE = 1;
			}
		}
	}
	fclose(fp);

	if (!foundS || !foundE)
	{
		printf("\n\tError: %s must contain both S and E.\n", filename);
		return 0;
	}
	return 1;
}

void save_score(char* name, int total, int cleared)
{
	FILE* fp = fopen("scores.txt", "a");
	if (fp == NULL)
	{
		printf("\n\tCould not save your score.\n");
		return;
	}
	fprintf(fp, "%s %d %d\n", name, total, cleared);
	fclose(fp);
}

void show_scores()
{
	FILE* fp = fopen("scores.txt", "r");
	char name[30];
	int total, cleared, count = 0;

	printf("\n\t------------ HIGH SCORES ------------\n");
	printf("\t%-20s %-8s %s\n", "Name", "Score", "Levels");

	if (fp == NULL)
	{
		printf("\n\tNo scores saved yet. Be the first!\n");
		return;
	}

	while (fscanf(fp, "%29s %d %d", name, &total, &cleared) == 3)
	{
		printf("\t%-20s %-8d %d/%d\n", name, total, cleared, LEVELS);
		count++;
	}
	fclose(fp);

	if (count == 0) printf("\n\tNo scores saved yet. Be the first!\n");
}

//------------------------------------------------------------------------------------------------------
//												MAZE HELPERS
//------------------------------------------------------------------------------------------------------

void copy_maze(char from[][MAX_C], char to[][MAX_C])
{
	int i, j;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
		{
			to[i][j] = from[i][j];
		}
	}
}

int count_cells(char maze[][MAX_C], char ch)
{
	int i, j, count = 0;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
		{
			if (maze[i][j] == ch) count++;
		}
	}
	return count;
}

void print_maze(char maze[][MAX_C], int pr, int pc, int show_dead)
{
	int i, j;
	char ch;

	printf("\n");
	for (i = 0; i < rows; i++)
	{
		printf("\t");
		for (j = 0; j < cols; j++)
		{
			ch = maze[i][j];

			if (i == pr && j == pc) ch = 'P';
			else if (ch == OPEN) ch = ' ';
			else if (ch == DEAD && !show_dead) ch = ' ';

			printf("%c ", ch);
		}
		printf("\n");
	}
	printf("\n");
}

//------------------------------------------------------------------------------------------------------
//									RECURSIVE BACKTRACKING SOLVER
//------------------------------------------------------------------------------------------------------

/*
	Tries to find a way from cell (r,c) to the exit.
	Returns 1 if a route exists, 0 if it does not.

	Base cases  : outside the maze / wall / already visited -> 0
				  reached the exit -> 1
	Choose      : mark the cell as part of the path
	Explore     : try UP, RIGHT, DOWN, LEFT (each one is a recursive call)
	Backtrack   : if all four directions fail, mark the cell as DEAD and return 0
*/
int solve(char maze[][MAX_C], int r, int c)
{
	calls++;

	if (r < 0 || r >= rows || c < 0 || c >= cols) return 0;		//Outside the maze
	if (maze[r][c] == EXIT) return 1;							//Reached the exit
	if (maze[r][c] == WALL || maze[r][c] == PATH || maze[r][c] == DEAD) return 0;

	maze[r][c] = PATH;											//Choose this cell

	if (solve(maze, r - 1, c)) return 1;						//Up
	if (solve(maze, r, c + 1)) return 1;						//Right
	if (solve(maze, r + 1, c)) return 1;						//Down
	if (solve(maze, r, c - 1)) return 1;						//Left

	maze[r][c] = DEAD;											//Nothing worked, undo
	backtracks++;
	return 0;
}

//Runs the solver on a COPY so the real maze is never damaged. Returns moves needed to reach E, or -1 if no route.
int run_solver(char maze[][MAX_C], char work[][MAX_C], int r, int c)
{
	copy_maze(maze, work);
	calls = 0;
	backtracks = 0;

	if (!solve(work, r, c)) return -1;

	return count_cells(work, PATH);		//One move for every cell on the route, ending on E
}

//------------------------------------------------------------------------------------------------------
//													GAMEPLAY
//------------------------------------------------------------------------------------------------------

void get_filename(int level, char* filename)
{
	sprintf(filename, "level%d.txt", level);
}

/*
	Plays one level.
	Returns the score of the level (0 or more), or -1 if the player quits.
*/
int play_level(int level)
{
	char maze[MAX_R][MAX_C], work[MAX_R][MAX_C];
	char filename[20], ch;
	int sr, sc, er, ec;

	get_filename(level, filename);
	if (!load_maze(filename, maze, &sr, &sc, &er, &ec)) return -1;

	int par = run_solver(maze, work, sr, sc);
	if (par == -1)
	{
		printf("\n\tThis maze has no solution, please fix %s.\n", filename);
		return -1;
	}

	int pr = sr, pc = sc;
	int moves = 0, hints = 0;
	int showing_hint = 0;
	int nr, nc;
	char message[60] = "Find the exit E!";

	while (!(pr == er && pc == ec))
	{
		system("cls");
		printf("\n\t======== LEVEL %d of %d ========\n", level, LEVELS);
		printf("\tMoves: %d     Hints left: %d     Par: %d\n", moves, MAX_HINTS - hints, par);
		printf("\t%s\n", message);

		if (showing_hint)
		{
			run_solver(maze, work, pr, pc);
			print_maze(work, pr, pc, 0);
			showing_hint = 0;
		}
		else
		{
			print_maze(maze, pr, pc, 0);
		}

		printf("\tW/A/S/D = move    H = hint    Q = quit level : ");
		ch = tolower(getch());

		nr = pr;
		nc = pc;
		strcpy(message, "");

		switch (ch)
		{
			case 'w': nr--; break;
			case 's': nr++; break;
			case 'a': nc--; break;
			case 'd': nc++; break;

			case 'h':
			{
				if (hints < MAX_HINTS)
				{
					hints++;
					showing_hint = 1;
					strcpy(message, "Hint: the * trail leads to the exit (-100 points).");
				}
				else strcpy(message, "No hints left!");
				break;
			}

			case 'q': return -1;

			default: strcpy(message, "Invalid key!"); break;
		}

		if (nr != pr || nc != pc)
		{
			if (maze[nr][nc] == WALL) strcpy(message, "Ouch! That is a wall.");
			else
			{
				pr = nr;
				pc = nc;
				moves++;
			}
		}
	}

	int score = 1000 - hints * 100;
	if (moves > par) score = score - (moves - par) * 10;
	if (score < 0) score = 0;

	system("cls");
	print_maze(maze, pr, pc, 0);
	printf("\n\tLEVEL %d CLEARED!\n", level);
	printf("\tMoves: %d    Par: %d    Hints used: %d\n", moves, par, hints);
	printf("\tLevel score: %d\n\n", score);
	return score;
}

void campaign()
{
	char name[30];
	int level, result;
	int total = 0, cleared = 0;

	printf("\n\tEnter your name (no spaces): ");
	scanf("%29s", name);

	for (level = 1; level <= LEVELS; level++)
	{
		result = play_level(level);

		if (result == -1) break;		//Player quit or the file was bad

		total = total + result;
		cleared++;

		if (level < LEVELS)
		{
			printf("\tPress any key for the next level: ");
			getch();
		}
	}

	if (cleared == LEVELS) printf("\n\tCongrats %s! You escaped ALL the mazes!\n", name);
	else printf("\n\tRun ended. You cleared %d of %d levels.\n", cleared, LEVELS);

	printf("\tTotal score: %d\n", total);
	save_score(name, total, cleared);
}

void select_level()
{
	int level;
	printf("\n\tSelect level (1-%d): ", LEVELS);
	if (scanf("%d", &level) != 1)
	{
		while (getchar() != '\n');
		printf("\n\tInvalid input.\n");
		return;
	}

	if (level < 1 || level > LEVELS)
	{
		printf("\n\tThat level does not exist.\n");
		return;
	}

	int result = play_level(level);
	if (result != -1) printf("\tPress any key to return to the menu: ");
	else printf("\n\tReturning to menu. Press any key: ");
	getch();
}

//Watch the recursive solver work on any level, including the dead ends it backtracked from
void solve_demo()
{
	char maze[MAX_R][MAX_C], work[MAX_R][MAX_C], filename[20];
	int sr, sc, er, ec, level;

	printf("\n\tWhich level should the solver escape (1-%d): ", LEVELS);
	if (scanf("%d", &level) != 1)
	{
		while (getchar() != '\n');
		printf("\n\tInvalid input.\n");
		return;
	}

	if (level < 1 || level > LEVELS)
	{
		printf("\n\tThat level does not exist.\n");
		return;
	}

	get_filename(level, filename);
	if (!load_maze(filename, maze, &sr, &sc, &er, &ec)) return;

	int steps = run_solver(maze, work, sr, sc);

	if (steps == -1)
	{
		printf("\n\tNo way out of this maze!\n");
		return;
	}

	system("cls");
	printf("\n\t======== SOLVER: LEVEL %d ========\n", level);
	printf("\t* = final route      x = dead ends that were backtracked\n");
	print_maze(work, -1, -1, 1);
	printf("\tRoute length      : %d moves\n", steps);
	printf("\tRecursive calls   : %d\n", calls);
	printf("\tBacktracks (dead) : %d\n\n", backtracks);
	printf("\tPress any key to return to the menu: ");
	getch();
}

void rules()
{
	printf("\n\t Rules : ");
	printf("\n\t - Reach the exit E starting from S. P is you.");
	printf("\n\t - Move with W (up), A (left), S (down), D (right).");
	printf("\n\t - Press H for a hint: the maze solver draws the route from where you stand.");
	printf("\n\t - You get only %d hints per level and each one costs 100 points.", MAX_HINTS);
	printf("\n\t - Every extra move beyond par costs 10 points. Max score per level is 1000.");
	printf("\n\t - Mazes are loaded from level1.txt, level2.txt and level3.txt.");
	printf("\n\t - You can edit those files to build your own mazes (# wall, . path, S, E).\n");
}

int main()
{
	int choice;

	do
	{
		printf("\n******Welcome to Multi-Level Maze Escape Runner*****\n");
		printf("\n\nMain Menu:\n");
		printf("1. Play Campaign\n2. Select Level\n3. Watch the Solver\n4. High Scores\n5. Rules\n6. Exit\n\n");

		if (scanf("%d", &choice) != 1)
		{
			while (getchar() != '\n');
			choice = 0;
		}

		switch (choice)
		{
			case 1: campaign(); break;
			case 2: select_level(); break;
			case 3: solve_demo(); break;
			case 4: show_scores(); break;
			case 5: rules(); break;
			case 6: printf("\n\tGoodbye!\n"); break;
			default: printf("\n\tPlease enter a number from 1 to 6.\n"); break;
		}
	}
	while (choice != 6);

	return 0;
}
