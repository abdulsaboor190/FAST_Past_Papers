#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <time.h>

#define MAX_WORDS 200
#define MAX_LEN 6
#define MAX_TRIES 7

int word_select = 0;
int rnd_index(int i);

//Reads every word of 4 to 6 letters from dictionary.txt into a 2D array
int load_dictionary(char dict[][MAX_LEN+1])
{
	FILE *fp = fopen("dictionary.txt", "r");
	char temp[50];
	int count = 0;
	int i, length;

	if(fp == NULL)
	{
		return 0;
	}

	while(count < MAX_WORDS && fscanf(fp, "%49s", temp) == 1)
	{
		length = strlen(temp);
		if(length >= 4 && length <= MAX_LEN)
		{
			for ( i = 0; i < length; i++)
			{
				temp[i] = tolower(temp[i]);
			}
			strcpy(dict[count], temp);
			count++;
		}
	}

	fclose(fp);
	return count;
}

//Used only when dictionary.txt is missing
int load_backup(char dict[][MAX_LEN+1])
{
	char backup[9][MAX_LEN+1] = {"bear", "lion", "wolf", "apple", "bread", "chair",
								 "planet", "garden", "bridge"};
	int i;
	for ( i = 0; i < 9; i++)
	{
		strcpy(dict[i], backup[i]);
	}
	return 9;
}

//Picks a random word that has exactly the required length
int pick_word(char dict[][MAX_LEN+1], int total, int len)
{
	int matches[MAX_WORDS];
	int count = 0;
	int i;

	for ( i = 0; i < total; i++)
	{
		if((int)strlen(dict[i]) == len)
		{
			matches[count] = i;
			count++;
		}
	}

	if(count == 0)
	{
		return -1;
	}
	return matches[rnd_index(count)];
}

//Checks length and that every character is an alphabet, converts to lower case
int valid_guess(char* guess, int len)
{
	int i;
	if((int)strlen(guess) != len)
	{
		return 0;
	}
	for ( i = 0; i < len; i++)
	{
		if(!isalpha(guess[i]))
		{
			return 0;
		}
		guess[i] = tolower(guess[i]);
	}
	return 1;
}

int already_guessed(char guesses[][MAX_LEN+1], int attempts, char* guess)
{
	int i;
	for ( i = 0; i < attempts; i++)
	{
		if(strcmp(guesses[i], guess) == 0)
		{
			return 1;
		}
	}
	return 0;
}

//X = right letter right place, * = right letter wrong place, _ = letter not in word
void check_guess(char* target, char* guess, char* result, int len)
{
	int used[MAX_LEN] = {0};
	int i, j;

	for ( i = 0; i < len; i++)
	{
		result[i] = '_';
	}
	result[len] = '\0';

	//First pass: exact matches
	for ( i = 0; i < len; i++)
	{
		if(guess[i] == target[i])
		{
			result[i] = 'X';
			used[i] = 1;
		}
	}

	//Second pass: letters present at some other position
	for ( i = 0; i < len; i++)
	{
		if(result[i] != 'X')
		{
			for ( j = 0; j < len; j++)
			{
				if(used[j] == 0 && guess[i] == target[j])
				{
					result[i] = '*';
					used[j] = 1;
					break;
				}
			}
		}
	}
}

//Keeps the best known status of every alphabet: X is better than * and * is better than _
void update_letters(char* status, char* guess, char* result, int len)
{
	int i, index;
	for ( i = 0; i < len; i++)
	{
		index = guess[i] - 'a';
		if(result[i] == 'X')
		{
			status[index] = 'X';
		}
		else if(result[i] == '*' && status[index] != 'X')
		{
			status[index] = '*';
		}
		else if(result[i] == '_' && status[index] == ' ')
		{
			status[index] = '_';
		}
	}
}

void display_letters(char* status)
{
	char marks[3] = {'X', '*', '_'};
	char *names[3] = {"Right place", "Wrong place", "Not in word"};
	int m, i;

	for ( m = 0; m < 3; m++)
	{
		printf("\t%s : ", names[m]);
		for ( i = 0; i < 26; i++)
		{
			if(status[i] == marks[m])
			{
				printf("%c ", 'a' + i);
			}
		}
		printf("\n");
	}
	printf("\n");
}

void display_board(char guesses[][MAX_LEN+1], char results[][MAX_LEN+1], int attempts, int len, int tries)
{
	int i, j;

	printf("\n\t===== WORDLE MATCH =====\n");
	printf("\tX = correct place   * = wrong place   _ = not in word\n\n");

	for ( i = 0; i < tries; i++)
	{
		printf("\t%d.  ", i + 1);
		if(i < attempts)
		{
			for ( j = 0; j < len; j++)
			{
				printf("%c ", guesses[i][j]);
			}
			printf("    ");
			for ( j = 0; j < len; j++)
			{
				printf("%c ", results[i][j]);
			}
		}
		else
		{
			for ( j = 0; j < len; j++)
			{
				printf(". ");
			}
		}
		printf("\n");
	}
	printf("\n");
}

//Returns a position whose letter has not been found yet, or -1 if none is left
int give_hint(char results[][MAX_LEN+1], int attempts, int len)
{
	int candidates[MAX_LEN];
	int count = 0;
	int i, r, found;

	for ( i = 0; i < len; i++)
	{
		found = 0;
		for ( r = 0; r < attempts; r++)
		{
			if(results[r][i] == 'X')
			{
				found = 1;
			}
		}
		if(found == 0)
		{
			candidates[count] = i;
			count++;
		}
	}

	if(count == 0)
	{
		return -1;
	}
	return candidates[rnd_index(count)];
}

//Plays one round and returns the points earned (0 means the round was lost)
int play_game(char dict[][MAX_LEN+1], int total, int len, int tries)
{
	char guesses[MAX_TRIES][MAX_LEN+1];
	char results[MAX_TRIES][MAX_LEN+1];
	char status[26];
	char input[50];
	char *target;
	int id = pick_word(dict, total, len);
	int attempts = 0;
	int won = 0;
	int hint_used = 0;
	int hint_pos = -1;
	int points;

	if(id == -1)
	{
		printf("\n\tNo %d letter words found in the dictionary.\n", len);
		return 0;
	}

	target = dict[id];
	memset(status, ' ', 26);

	while(attempts < tries && won == 0)
	{
		system("cls");
		display_board(guesses, results, attempts, len, tries);
		display_letters(status);

		if(hint_pos != -1)
		{
			printf("\tHINT: Letter %d is '%c'\n\n", hint_pos + 1, target[hint_pos]);
		}

		printf("\tEnter a %d letter word (attempt %d of %d)", len, attempts + 1, tries);
		if(hint_used == 0)
		{
			printf(" or ? for a hint (-5 points)");
		}
		printf(": ");
		scanf("%49s", input);

		if(strcmp(input, "?") == 0)
		{
			if(hint_used == 0)
			{
				hint_pos = give_hint(results, attempts, len);
				if(hint_pos != -1)
				{
					hint_used = 1;
				}
			}
			continue;
		}

		if(valid_guess(input, len) == 0)
		{
			printf("\n\tInvalid word! Enter exactly %d alphabets.\n\tPress any key to continue...", len);
			getch();
			continue;
		}

		if(already_guessed(guesses, attempts, input) == 1)
		{
			printf("\n\tYou already tried that word!\n\tPress any key to continue...");
			getch();
			continue;
		}

		strcpy(guesses[attempts], input);
		check_guess(target, input, results[attempts], len);
		update_letters(status, input, results[attempts], len);

		if(strcmp(input, target) == 0)
		{
			won = 1;
		}
		attempts++;
	}

	system("cls");
	display_board(guesses, results, attempts, len, tries);

	if(won == 1)
	{
		points = (tries - attempts + 1) * 10;
		if(hint_used == 1)
		{
			points = points - 5;
		}
		printf("\tCongrats! You guessed it in %d attempt(s).\n", attempts);
		printf("\tThe word is: %s\n", target);
		printf("\tPoints earned: %d\n\n", points);
		return points;
	}

	printf("\tBetter luck next time. The word was %s\n\n", target);
	return 0;
}

int load_highscore()
{
	FILE *fp = fopen("highscore.txt", "r");
	int best = 0;

	if(fp == NULL)
	{
		return 0;
	}
	fscanf(fp, "%d", &best);
	fclose(fp);
	return best;
}

void save_highscore(int best)
{
	FILE *fp = fopen("highscore.txt", "w");

	if(fp == NULL)
	{
		return;
	}
	fprintf(fp, "%d", best);
	fclose(fp);
}

void rules()
{
	printf("\n\t Rules : ");
	printf("\n\t - Guess the hidden word before your tries run out.");
	printf("\n\t - Easy = 4 letters, 7 tries | Medium = 5 letters, 6 tries | Hard = 6 letters, 5 tries.");
	printf("\n\t - Enter alphabets only, in any case. A word cannot be repeated.");
	printf("\n\t - After each guess you get a match pattern:");
	printf("\n\t     X  letter is correct and in the right place");
	printf("\n\t     *  letter is in the word but in the wrong place");
	printf("\n\t     _  letter is not in the word");
	printf("\n\t - Type ? once per round for a hint, it costs 5 points.");
	printf("\n\t - Points for a win = (tries left + 1) x 10.\n\n");
}

int main()
{
	char dict[MAX_WORDS][MAX_LEN+1];
	int total;
	int choice, level;
	int len, tries;
	int points;
	int games = 0, wins = 0, streak = 0, total_score = 0;
	int high_score = load_highscore();

	total = load_dictionary(dict);
	if(total == 0)
	{
		printf("dictionary.txt not found. Using the built-in word list.\n");
		total = load_backup(dict);
	}

	do
	{
		printf("\n******Welcome to Wordle Match Simulation Engine*****\n");
		printf("\n1. PLAY\n2. RULES\n3. STATS\n4. EXIT\n\n");
		scanf("%d", &choice);

		switch(choice)
		{
			case 1:				//Play
			{
				printf("\n\tSelect Difficulty level:\n");
				printf("\n1.Easy (4 letters)\t2.Medium (5 letters)\t3.Hard (6 letters)\n\n");
				scanf("%d", &level);

				switch(level)
				{
					case 1: len = 4; tries = 7; break;
					case 2: len = 5; tries = 6; break;
					case 3: len = 6; tries = 5; break;
					default:
					{
						printf("\n\tInvalid level! Medium selected.\n");
						len = 5;
						tries = 6;
						break;
					}
				}

				points = play_game(dict, total, len, tries);
				games++;

				if(points > 0)
				{
					wins++;
					streak++;
					total_score = total_score + points;
					if(total_score > high_score)
					{
						high_score = total_score;
						save_highscore(high_score);
						printf("\tNEW HIGH SCORE: %d\n", high_score);
					}
				}
				else
				{
					streak = 0;
				}
				break;
			}
			case 2:				//Rules
			{
				rules();
				break;
			}
			case 3:				//Stats
			{
				printf("\n\t===== STATS =====");
				printf("\n\tGames played   : %d", games);
				printf("\n\tGames won      : %d", wins);
				if(games > 0)
				{
					printf("\n\tWin percentage : %.1f%%", (float)wins / games * 100);
				}
				printf("\n\tCurrent streak : %d", streak);
				printf("\n\tScore          : %d", total_score);
				printf("\n\tHigh score     : %d\n\n", high_score);
				break;
			}
			case 4:				//Exit
			{
				printf("\n\tGoodbye!\n");
				break;
			}
			default:
			{
				printf("\n\tInvalid choice!\n");
				break;
			}
		}
	} while(choice != 4);

	return 0;
}

int rnd_index(int i)
{
	if (word_select == 0)
	{
		srand(time(NULL) << 5);
		word_select = 1;
	}

	return rand() % i;
}
