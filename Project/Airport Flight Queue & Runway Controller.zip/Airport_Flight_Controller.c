#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>

#define START_CAP 4
#define RUNWAYS 2
#define SLOT 5

struct Flight
{
	char code[10];
	int fuel;			//minutes of fuel remaining
	int passengers;
	int emergency;		//0 = none, 1 = medical, 2 = mechanical
	int priority;
	int runway;
	int eta;			//minutes until landing
};

void to_upper(char *s)
{
	while(*s != '\0')
	{
		*s = toupper(*s);
		s++;
	}
}

//Keeps asking until the player enters a whole number between min and max
int read_int(char *prompt, int min, int max)
{
	int value;

	while(1)
	{
		printf("%s", prompt);
		if(scanf("%d", &value) != 1)
		{
			while(getchar() != '\n');
			printf("\tInvalid input!\n");
		}
		else if(value < min || value > max)
		{
			printf("\tEnter a value from %d to %d!\n", min, max);
		}
		else
		{
			return value;
		}
	}
}

char* emergency_name(int e)
{
	switch(e)
	{
		case 1: return "Medical";
		case 2: return "Mechanical";
		default: return "None";
	}
}

//Higher score = lands earlier
int calc_priority(struct Flight *f)
{
	int score = 0;

	if(f->fuel < 10)
	{
		score += 100;
	}
	else if(f->fuel < 20)
	{
		score += 70;
	}
	else if(f->fuel < 40)
	{
		score += 40;
	}
	else if(f->fuel < 60)
	{
		score += 20;
	}

	if(f->emergency == 1)
	{
		score += 60;
	}
	else if(f->emergency == 2)
	{
		score += 90;
	}

	score += f->passengers / 50;
	return score;
}

struct Flight* find_flight(struct Flight *queue, int count, char *code)
{
	int i;
	for ( i = 0; i < count; i++)
	{
		if(strcmp((queue + i)->code, code) == 0)
		{
			return queue + i;
		}
	}
	return NULL;
}

//Adds a flight and doubles the array when it is full, returns 1 on success
int add_flight(struct Flight **queue, int *count, int *capacity, struct Flight f)
{
	struct Flight *temp;

	if(*count == *capacity)
	{
		temp = (struct Flight*)realloc(*queue, (*capacity) * 2 * sizeof(struct Flight));
		if(temp == NULL)
		{
			printf("\n\tMemory error! Flight could not be added.\n");
			return 0;
		}
		*queue = temp;
		*capacity = *capacity * 2;
		printf("\n\t[Queue expanded to %d slots]\n", *capacity);
	}

	f.priority = calc_priority(&f);
	f.runway = 0;
	f.eta = 0;
	*(*queue + *count) = f;
	(*count)++;
	return 1;
}

//Selection by bubble sort: highest priority first, lower fuel breaks a tie
void sort_queue(struct Flight *queue, int count)
{
	int i, j;
	struct Flight temp;

	for ( i = 0; i < count - 1; i++)
	{
		for ( j = 0; j < count - i - 1; j++)
		{
			if((queue + j)->priority < (queue + j + 1)->priority ||
			  ((queue + j)->priority == (queue + j + 1)->priority && (queue + j)->fuel > (queue + j + 1)->fuel))
			{
				temp = *(queue + j);
				*(queue + j) = *(queue + j + 1);
				*(queue + j + 1) = temp;
			}
		}
	}
}

//Refreshes priorities, sorts the queue and gives every flight a runway and landing time
void schedule_flights(struct Flight *queue, int count)
{
	int runway_free[RUNWAYS] = {0};
	int i, r, best;

	for ( i = 0; i < count; i++)
	{
		(queue + i)->priority = calc_priority(queue + i);
	}

	sort_queue(queue, count);

	for ( i = 0; i < count; i++)
	{
		best = 0;
		for ( r = 1; r < RUNWAYS; r++)
		{
			if(runway_free[r] < runway_free[best])
			{
				best = r;
			}
		}
		(queue + i)->runway = best + 1;
		(queue + i)->eta = runway_free[best];
		runway_free[best] = runway_free[best] + SLOT;
	}
}

char* get_status(struct Flight *f)
{
	if(f->eta > f->fuel)
	{
		return "DIVERT - fuel too low";
	}
	if(f->emergency != 0)
	{
		return "EMERGENCY";
	}
	if(f->fuel - f->eta < 10)
	{
		return "LOW FUEL";
	}
	return "OK";
}

//Works for the screen (stdout) and for a file
void print_manifest(FILE *out, struct Flight *queue, int count)
{
	int i;
	struct Flight *f;

	fprintf(out, "\n\t===== LANDING SEQUENCE MANIFEST =====\n\n");
	fprintf(out, "\t%-5s%-10s%-6s%-6s%-12s%-10s%-8s%-6s%s\n", "Seq", "Flight", "Fuel", "Pax", "Emergency", "Priority", "Runway", "ETA", "Status");
	fprintf(out, "\t--------------------------------------------------------------------------------\n");

	for ( i = 0; i < count; i++)
	{
		f = queue + i;
		fprintf(out, "\t%-5d%-10s%-6d%-6d%-12s%-10d%-8d%-6d%s\n", i + 1, f->code, f->fuel, f->passengers,
				emergency_name(f->emergency), f->priority, f->runway, f->eta, get_status(f));
	}

	fprintf(out, "\n\tFlights in sequence : %d\n", count);
	if(count > 0)
	{
		fprintf(out, "\tFinal landing in    : about %d minute(s)\n", (queue + count - 1)->eta);
	}
	fprintf(out, "\n");
}

void print_queue(struct Flight *queue, int count)
{
	int i;
	struct Flight *f;

	printf("\n\t===== ARRIVAL QUEUE =====\n\n");
	if(count == 0)
	{
		printf("\tNo aircraft in the queue.\n\n");
		return;
	}

	printf("\t%-10s%-6s%-6s%-12s%s\n", "Flight", "Fuel", "Pax", "Emergency", "Priority");
	printf("\t----------------------------------------------\n");
	for ( i = 0; i < count; i++)
	{
		f = queue + i;
		printf("\t%-10s%-6d%-6d%-12s%d\n", f->code, f->fuel, f->passengers, emergency_name(f->emergency), f->priority);
	}
	printf("\n");
}

void add_flight_menu(struct Flight **queue, int *count, int *capacity)
{
	struct Flight f;
	char code[20];

	printf("\n\tEnter flight code (max 9 characters): ");
	scanf("%19s", code);
	while(getchar() != '\n');

	if(strlen(code) > 9)
	{
		printf("\n\tFlight code is too long!\n");
		return;
	}

	to_upper(code);
	if(find_flight(*queue, *count, code) != NULL)
	{
		printf("\n\tFlight %s is already in the queue!\n", code);
		return;
	}

	strcpy(f.code, code);
	f.fuel = read_int("\tFuel remaining in minutes (1-300): ", 1, 300);
	f.passengers = read_int("\tNumber of passengers (1-600): ", 1, 600);
	f.emergency = read_int("\tEmergency (0 = None, 1 = Medical, 2 = Mechanical): ", 0, 2);

	if(add_flight(queue, count, capacity, f) == 1)
	{
		printf("\n\tFlight %s added with priority %d.\n", f.code, (*queue + *count - 1)->priority);
	}
}

void update_flight_menu(struct Flight *queue, int count)
{
	struct Flight *f;
	char code[20];

	printf("\n\tEnter flight code to update: ");
	scanf("%19s", code);
	while(getchar() != '\n');
	to_upper(code);

	f = find_flight(queue, count, code);
	if(f == NULL)
	{
		printf("\n\tFlight %s was not found.\n", code);
		return;
	}

	f->fuel = read_int("\tNew fuel remaining in minutes (1-300): ", 1, 300);
	f->emergency = read_int("\tEmergency (0 = None, 1 = Medical, 2 = Mechanical): ", 0, 2);
	f->priority = calc_priority(f);
	printf("\n\tFlight %s updated. New priority: %d\n", f->code, f->priority);
}

//Clears the top priority flight to land, the others burn fuel while waiting
void land_next(struct Flight **queue, int *count, int *capacity)
{
	struct Flight *temp;
	struct Flight landed;
	int i;

	if(*count == 0)
	{
		printf("\n\tNo aircraft are waiting to land.\n");
		return;
	}

	schedule_flights(*queue, *count);
	landed = **queue;

	printf("\n\tFlight %s is cleared to land on runway %d.\n", landed.code, landed.runway);
	printf("\tFlight %s has landed safely with %d minute(s) of fuel left.\n", landed.code, landed.fuel);

	for ( i = 0; i < *count - 1; i++)
	{
		*(*queue + i) = *(*queue + i + 1);
	}
	(*count)--;

	for ( i = 0; i < *count; i++)
	{
		(*queue + i)->fuel = (*queue + i)->fuel - SLOT;
		if((*queue + i)->fuel <= 0)
		{
			(*queue + i)->fuel = 0;
			printf("\n\tMAYDAY! Flight %s has run out of fuel! Land immediately!\n", (*queue + i)->code);
		}
		(*queue + i)->priority = calc_priority(*queue + i);
	}

	//Shrink the array when most of it is empty
	if(*capacity > START_CAP && *count <= *capacity / 4)
	{
		temp = (struct Flight*)realloc(*queue, (*capacity / 2) * sizeof(struct Flight));
		if(temp != NULL)
		{
			*queue = temp;
			*capacity = *capacity / 2;
			printf("\n\t[Queue shrunk to %d slots]\n", *capacity);
		}
	}
}

void save_manifest(struct Flight *queue, int count)
{
	FILE *fp;

	if(count == 0)
	{
		printf("\n\tNothing to save, the queue is empty.\n");
		return;
	}

	fp = fopen("manifest.txt", "w");
	if(fp == NULL)
	{
		printf("\n\tCould not open manifest.txt for writing.\n");
		return;
	}

	schedule_flights(queue, count);
	print_manifest(fp, queue, count);
	fclose(fp);
	printf("\n\tManifest saved to manifest.txt\n");
}

int load_flights(struct Flight **queue, int *count, int *capacity)
{
	FILE *fp = fopen("flights.txt", "r");
	struct Flight f;
	int loaded = 0;

	if(fp == NULL)
	{
		return 0;
	}

	while(fscanf(fp, "%9s %d %d %d", f.code, &f.fuel, &f.passengers, &f.emergency) == 4)
	{
		to_upper(f.code);
		if(f.fuel > 0 && f.passengers > 0 && f.emergency >= 0 && f.emergency <= 2 && find_flight(*queue, *count, f.code) == NULL)
		{
			if(add_flight(queue, count, capacity, f) == 1)
			{
				loaded++;
			}
		}
	}

	fclose(fp);
	return loaded;
}

void save_flights(struct Flight *queue, int count)
{
	FILE *fp = fopen("flights.txt", "w");
	int i;

	if(fp == NULL)
	{
		printf("\n\tCould not save the queue to flights.txt\n");
		return;
	}

	for ( i = 0; i < count; i++)
	{
		fprintf(fp, "%s %d %d %d\n", (queue + i)->code, (queue + i)->fuel, (queue + i)->passengers, (queue + i)->emergency);
	}
	fclose(fp);
	printf("\n\tQueue saved to flights.txt\n");
}

int main()
{
	int capacity = START_CAP;
	int count = 0;
	int choice, loaded;
	struct Flight *queue = (struct Flight*)malloc(capacity * sizeof(struct Flight));

	if(queue == NULL)
	{
		printf("Memory error!\n");
		return 1;
	}

	loaded = load_flights(&queue, &count, &capacity);
	if(loaded > 0)
	{
		printf("\n%d flight(s) loaded from flights.txt\n", loaded);
	}

	do
	{
		printf("\n******Welcome to Airport Flight Queue & Runway Controller*****\n");
		printf("\n1. ADD ARRIVING FLIGHT\n2. SHOW ARRIVAL QUEUE\n3. GENERATE LANDING SEQUENCE\n4. UPDATE A FLIGHT\n5. CLEAR NEXT FLIGHT TO LAND\n6. SAVE MANIFEST TO FILE\n7. EXIT\n\n");
		scanf("%d", &choice);

		switch(choice)
		{
			case 1:				//Add
			{
				add_flight_menu(&queue, &count, &capacity);
				break;
			}
			case 2:				//Queue
			{
				print_queue(queue, count);
				break;
			}
			case 3:				//Sequence
			{
				schedule_flights(queue, count);
				print_manifest(stdout, queue, count);
				break;
			}
			case 4:				//Update
			{
				update_flight_menu(queue, count);
				break;
			}
			case 5:				//Land
			{
				land_next(&queue, &count, &capacity);
				break;
			}
			case 6:				//Save manifest
			{
				save_manifest(queue, count);
				break;
			}
			case 7:				//Exit
			{
				save_flights(queue, count);
				printf("\n\tGoodbye, Controller!\n");
				break;
			}
			default:
			{
				printf("\n\tInvalid choice!\n");
				break;
			}
		}
	} while(choice != 7);

	free(queue);
	return 0;
}
