#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>

#define SIZE 9				//The board is 9 x 9
#define BOX 3				//Each small box is 3 x 3

int moves = 0;				//Numbers placed by the solver
int backtracks = 0;			//Numbers the solver had to take back
int calls = 0;				//Recursive calls made
int stepping = 0;			//1 = show every step of the solver on the screen

//------------------------------------------------------------------------------------------------------
//												FILE INPUT / OUTPUT
//------------------------------------------------------------------------------------------------------

/*
	Puzzle file format: 9 lines, each with 9 characters.
	1-9 = given number     0 or . = empty cell
*/
int load_puzzle(char* filename, int g[][SIZE])
{
	FILE* fp = fopen(filename, "r");
	if (fp == NULL)
	{
		printf("\n\tError: could not open %s\n", filename);
		return 0;
	}

	int i, j;
	char line[50];

	for (i = 0; i < SIZE; i++)
	{
		if (fscanf(fp, "%49s", line) != 1 || strlen(line) != SIZE)
		{
			printf("\n\tError: line %d of %s must have exactly %d characters.\n", i + 1, filename, SIZE);
			fclose(fp);
			return 0;
		}

		for (j = 0; j < SIZE; j++)
		{
			if (line[j] == '.' || line[j] == '0') g[i][j] = 0;
			else if (line[j] >= '1' && line[j] <= '9') g[i][j] = line[j] - '0';
			else
			{
				printf("\n\tError: invalid character '%c' on line %d of %s.\n", line[j], i + 1, filename);
				fclose(fp);
				return 0;
			}
		}
	}
	fclose(fp);
	return 1;
}

void save_solution(int g[][SIZE])
{
	FILE* fp = fopen("solution.txt", "w");
	if (fp == NULL)
	{
		printf("\n\tCould not create solution.txt\n");
		return;
	}

	int i, j;
	for (i = 0; i < SIZE; i++)
	{
		for (j = 0; j < SIZE; j++)
		{
			fprintf(fp, "%d", g[i][j]);
		}
		fprintf(fp, "\n");
	}
	fclose(fp);
	printf("\n\tBoard saved to solution.txt (it can be loaded again like a puzzle).\n");
}

//------------------------------------------------------------------------------------------------------
//												BOARD HELPERS
//------------------------------------------------------------------------------------------------------

void copy_grid(int from[][SIZE], int to[][SIZE])
{
	int i, j;
	for (i = 0; i < SIZE; i++)
	{
		for (j = 0; j < SIZE; j++)
		{
			to[i][j] = from[i][j];
		}
	}
}

//hr, hc = cell to highlight with [ ]  (use -1, -1 for none)
void print_grid(int g[][SIZE], int hr, int hc)
{
	int i, j;

	printf("\n\t     1  2  3   4  5  6   7  8  9\n");
	for (i = 0; i < SIZE; i++)
	{
		if (i % BOX == 0) printf("\t   +---------+---------+---------+\n");
		printf("\t %d |", i + 1);

		for (j = 0; j < SIZE; j++)
		{
			if (i == hr && j == hc) printf("[%d]", g[i][j]);
			else if (g[i][j] == 0) printf(" . ");
			else printf(" %d ", g[i][j]);

			if (j % BOX == BOX - 1) printf("|");
		}
		printf("\n");
	}
	printf("\t   +---------+---------+---------+\n\n");
}

int count_empty(int g[][SIZE])
{
	int i, j, count = 0;
	for (i = 0; i < SIZE; i++)
	{
		for (j = 0; j < SIZE; j++)
		{
			if (g[i][j] == 0) count++;
		}
	}
	return count;
}

//------------------------------------------------------------------------------------------------------
//													VALIDATOR
//------------------------------------------------------------------------------------------------------

//Each function returns how many repeated numbers it found. show = 1 prints them.
int check_rows(int g[][SIZE], int show)
{
	int r, c, num, bad = 0;
	int seen[SIZE + 1];

	for (r = 0; r < SIZE; r++)
	{
		memset(seen, 0, sizeof(seen));
		for (c = 0; c < SIZE; c++)
		{
			num = g[r][c];
			if (num == 0) continue;

			if (seen[num])
			{
				if (show) printf("\tRow %d has a repeated %d\n", r + 1, num);
				bad++;
			}
			seen[num] = 1;
		}
	}
	return bad;
}

int check_columns(int g[][SIZE], int show)
{
	int r, c, num, bad = 0;
	int seen[SIZE + 1];

	for (c = 0; c < SIZE; c++)
	{
		memset(seen, 0, sizeof(seen));
		for (r = 0; r < SIZE; r++)
		{
			num = g[r][c];
			if (num == 0) continue;

			if (seen[num])
			{
				if (show) printf("\tColumn %d has a repeated %d\n", c + 1, num);
				bad++;
			}
			seen[num] = 1;
		}
	}
	return bad;
}

int check_boxes(int g[][SIZE], int show)
{
	int b, i, j, num, bad = 0;
	int seen[SIZE + 1];

	for (b = 0; b < SIZE; b++)
	{
		int br = (b / BOX) * BOX;			//Top row of this box
		int bc = (b % BOX) * BOX;			//Left column of this box

		memset(seen, 0, sizeof(seen));
		for (i = 0; i < BOX; i++)
		{
			for (j = 0; j < BOX; j++)
			{
				num = g[br + i][bc + j];
				if (num == 0) continue;

				if (seen[num])
				{
					if (show) printf("\tBox %d (row %d-%d, column %d-%d) has a repeated %d\n", b + 1, br + 1, br + BOX, bc + 1, bc + BOX, num);
					bad++;
				}
				seen[num] = 1;
			}
		}
	}
	return bad;
}

int validate_grid(int g[][SIZE], int show)
{
	int bad = check_rows(g, show) + check_columns(g, show) + check_boxes(g, show);

	if (show)
	{
		if (bad == 0)
		{
			if (count_empty(g) == 0) printf("\n\tVALID and COMPLETE: every row, column and box has 1-9 once.\n");
			else printf("\n\tVALID so far: no repeated numbers. %d cells are still empty.\n", count_empty(g));
		}
		else printf("\n\tINVALID: %d problem(s) found.\n", bad);
	}
	return bad;
}

//------------------------------------------------------------------------------------------------------
//									RECURSIVE BACKTRACKING SOLVER
//------------------------------------------------------------------------------------------------------

//Can num be written at (r,c) without breaking the row, column or box rule?
int is_safe(int g[][SIZE], int r, int c, int num)
{
	int i, j;

	for (i = 0; i < SIZE; i++)
	{
		if (g[r][i] == num) return 0;
		if (g[i][c] == num) return 0;
	}

	int br = (r / BOX) * BOX;
	int bc = (c / BOX) * BOX;
	for (i = 0; i < BOX; i++)
	{
		for (j = 0; j < BOX; j++)
		{
			if (g[br + i][bc + j] == num) return 0;
		}
	}
	return 1;
}

//Finds the next empty cell. Returns 0 if the board is full.
int find_empty(int g[][SIZE], int* r, int* c)
{
	int i, j;
	for (i = 0; i < SIZE; i++)
	{
		for (j = 0; j < SIZE; j++)
		{
			if (g[i][j] == 0)
			{
				*r = i;
				*c = j;
				return 1;
			}
		}
	}
	return 0;
}

void show_step(int g[][SIZE], int r, int c, char* message)
{
	system("cls");
	printf("\n\t======== SOLVING STEP BY STEP ========\n");
	printf("\tMoves: %d     Backtracks: %d\n", moves, backtracks);
	print_grid(g, r, c);
	printf("\t%s\n", message);
	printf("\tPress any key for the next step (Q = finish instantly): ");

	if (tolower(getch()) == 'q') stepping = 0;
}

/*
	Fills the board using recursion.
	Base case  : no empty cell left -> solved, return 1
	Choose     : take the next empty cell and try 1 to 9
	Explore    : if the number is safe, place it and call solve() again
	Backtrack  : if the recursive call fails, remove the number and try the next one
	Returns 0 if no number fits (the caller must change its own choice).
*/
int solve(int g[][SIZE])
{
	int r, c, num;
	char message[100];

	calls++;

	if (!find_empty(g, &r, &c)) return 1;

	for (num = 1; num <= SIZE; num++)
	{
		if (is_safe(g, r, c, num))
		{
			g[r][c] = num;
			moves++;

			if (stepping)
			{
				sprintf(message, "Placed %d at row %d, column %d", num, r + 1, c + 1);
				show_step(g, r, c, message);
			}

			if (solve(g)) return 1;

			g[r][c] = 0;				//Dead end, undo
			backtracks++;

			if (stepping)
			{
				sprintf(message, "Backtrack: removed %d from row %d, column %d", num, r + 1, c + 1);
				show_step(g, r, c, message);
			}
		}
	}
	return 0;
}

//Solves g in place and prints the statistics. step = 1 shows every move.
void run_solver(int g[][SIZE], int step)
{
	if (validate_grid(g, 0) != 0)
	{
		printf("\n\tThe puzzle has repeated numbers, so it cannot be solved. Use option 3 to see them.\n");
		return;
	}

	int empty = count_empty(g);
	moves = 0;
	backtracks = 0;
	calls = 0;
	stepping = step;

	int solved = solve(g);
	stepping = 0;

	if (solved)
	{
		system("cls");
		printf("\n\t======== SOLVED ========\n");
		print_grid(g, -1, -1);
		printf("\tEmpty cells filled : %d\n", empty);
		printf("\tMoves needed       : %d\n", moves);
		printf("\tBacktracks         : %d\n", backtracks);
		printf("\tRecursive calls    : %d\n", calls);
		validate_grid(g, 1);
	}
	else printf("\n\tThis puzzle has NO solution. The board was left unchanged.\n");
}

//Reveals one cell by solving a copy of the board
void give_hint(int g[][SIZE])
{
	int work[SIZE][SIZE];
	int r, c;

	if (validate_grid(g, 0) != 0)
	{
		printf("\n\tThe puzzle has repeated numbers, fix it first (option 3).\n");
		return;
	}

	printf("\n\tEnter the row and column (1-9) of the cell: ");
	if (scanf("%d %d", &r, &c) != 2)
	{
		while (getchar() != '\n');
		printf("\n\tInvalid input.\n");
		return;
	}

	if (r < 1 || r > SIZE || c < 1 || c > SIZE)
	{
		printf("\n\tRow and column must be between 1 and %d.\n", SIZE);
		return;
	}
	r--;
	c--;

	if (g[r][c] != 0)
	{
		printf("\n\tThat cell already has %d.\n", g[r][c]);
		return;
	}

	copy_grid(g, work);
	stepping = 0;
	moves = 0;
	backtracks = 0;
	calls = 0;

	if (!solve(work))
	{
		printf("\n\tThis puzzle has no solution, so no hint is possible.\n");
		return;
	}

	g[r][c] = work[r][c];
	printf("\n\tHint: row %d, column %d is %d (it has been filled in).\n", r + 1, c + 1, g[r][c]);
	print_grid(g, r, c);
}

int main()
{
	int grid[SIZE][SIZE];
	int loaded = 0;
	int choice;
	char filename[50];

	do
	{
		printf("\n******Welcome to Sudoku Solver & Validator*****\n");
		printf("\n\nMain Menu:\n");
		printf("1. Load Puzzle from File\n2. Show Board\n3. Validate Board\n4. Hint for One Cell\n5. Solve (Instant)\n6. Solve Step by Step\n7. Save Board to File\n8. Exit\n\n");

		if (scanf("%d", &choice) != 1)
		{
			while (getchar() != '\n');
			choice = 0;
		}

		if (choice >= 2 && choice <= 7 && !loaded)
		{
			printf("\n\tLoad a puzzle first (option 1).\n");
			continue;
		}

		switch (choice)
		{
			case 1:
			{
				printf("\n\tEnter the puzzle file name (e.g. puzzle1.txt): ");
				scanf("%49s", filename);

				if (load_puzzle(filename, grid))
				{
					loaded = 1;
					printf("\n\tLoaded %s. It has %d empty cells.\n", filename, count_empty(grid));
					print_grid(grid, -1, -1);
				}
				break;
			}
			case 2: print_grid(grid, -1, -1); break;
			case 3: print_grid(grid, -1, -1); validate_grid(grid, 1); break;
			case 4: give_hint(grid); break;
			case 5: run_solver(grid, 0); break;
			case 6: run_solver(grid, 1); break;
			case 7: save_solution(grid); break;
			case 8: printf("\n\tGoodbye!\n"); break;
			default: printf("\n\tPlease enter a number from 1 to 8.\n"); break;
		}
	}
	while (choice != 8);

	return 0;
}
