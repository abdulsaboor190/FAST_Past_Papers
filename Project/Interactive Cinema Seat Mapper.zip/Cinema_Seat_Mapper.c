#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <windows.h>

#define ROWS 8
#define COLS 16
#define MOVIE_INFO "NOW SHOWING: THE LAST FRONTIER   |   Hall 3   |   Tonight 9:00 PM"

//Screen rows used by the layout
#define PANEL_ROW 16
#define ERROR_ROW 20
#define SUMMARY_ROW 21
#define MESSAGE_ROW 22

//Console colors
#define C_BLACK 0
#define C_GREEN 10
#define C_CYAN 11
#define C_RED 12
#define C_MAGENTA 13
#define C_YELLOW 14
#define C_WHITE 15
#define C_GRAY 8

struct Customer
{
	char name[30];
	char phone[12];
	int age;
};

struct Booking
{
	int id;
	int ticket_price;
	struct Customer customer;
};

struct Seat
{
	int exists;			//0 = aisle gap, 1 = real seat
	int category;		//0 = Standard, 1 = Premium, 2 = VIP
	int price;
	int booked;
	struct Booking booking;
};

char message[100] = "";

char category_names[3][10] = {"Standard", "Premium", "VIP"};
int category_prices[3] = {600, 900, 1400};
int category_colors[3] = {C_GRAY, C_CYAN, C_MAGENTA};

char default_layout[ROWS][COLS + 1] = {"..SSSS....SSSS..", ".SSSSSS..SSSSSS.", "SSSSSSS..SSSSSSS", "SSSSSSS..SSSSSSS",
									   "SSSSSSS..SSSSSSS", "SSSSSSS..SSSSSSS", "SSSSSSS..SSSSSSS", "SSSSSSS..SSSSSSS"};

//---------------------------------------- console helpers ----------------------------------------

void move_to(int x, int y)
{
	COORD pos;
	pos.X = x;
	pos.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void paint(int attribute)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), attribute);
}

void show_cursor(int visible)
{
	CONSOLE_CURSOR_INFO info;
	info.dwSize = 20;
	info.bVisible = visible;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info);
}

//---------------------------------------- string helpers ----------------------------------------

//Reads a whole line (spaces allowed) and removes the newline
void read_line(char *buf, int size)
{
	int len;

	fgets(buf, size, stdin);
	len = strlen(buf);
	if(len > 0 && buf[len - 1] == '\n')
	{
		buf[len - 1] = '\0';
	}
}

int valid_name(char *name)
{
	int i;
	int letters = 0;
	int len = strlen(name);

	if(len < 2 || len > 29)
	{
		return 0;
	}
	for ( i = 0; i < len; i++)
	{
		if(isalpha(name[i]))
		{
			letters++;
		}
		else if(name[i] != ' ')
		{
			return 0;
		}
	}
	return letters >= 2;
}

int all_digits(char *s)
{
	int i;
	if(strlen(s) == 0)
	{
		return 0;
	}
	for ( i = 0; s[i] != '\0'; i++)
	{
		if(!isdigit(s[i]))
		{
			return 0;
		}
	}
	return 1;
}

//ali raza khan -> Ali Raza Khan
void capitalize_name(char *name)
{
	int new_word = 1;
	while(*name != '\0')
	{
		if(*name == ' ')
		{
			new_word = 1;
		}
		else if(new_word == 1)
		{
			*name = toupper(*name);
			new_word = 0;
		}
		else
		{
			*name = tolower(*name);
		}
		name++;
	}
}

void lower_copy(char *dest, char *src, int size)
{
	int i;
	for ( i = 0; i < size - 1 && src[i] != '\0'; i++)
	{
		dest[i] = tolower(src[i]);
	}
	dest[i] = '\0';
}

//Case insensitive check that part appears inside text
int contains_text(char *text, char *part)
{
	char t[50], p[50];

	lower_copy(t, text, 50);
	lower_copy(p, part, 50);
	return strstr(t, p) != NULL;
}

//---------------------------------------- hall setup ----------------------------------------

int category_of_row(int r)
{
	if(r < 3)
	{
		return 0;
	}
	else if(r < 6)
	{
		return 1;
	}
	return 2;
}

//Reads layout.txt (S = seat, anything else = gap). Falls back to the built-in layout. Returns 1 if the file was used
int load_layout(struct Seat hall[][COLS])
{
	FILE *fp = fopen("layout.txt", "r");
	char rows[ROWS][50];
	int count = 0;
	int used_file = 0;
	int r, c;

	if(fp != NULL)
	{
		while(count < ROWS && fgets(rows[count], 50, fp) != NULL)
		{
			count++;
		}
		fclose(fp);
		if(count == ROWS)
		{
			used_file = 1;
		}
	}

	if(used_file == 0)
	{
		for ( r = 0; r < ROWS; r++)
		{
			strcpy(rows[r], default_layout[r]);
		}
	}

	for ( r = 0; r < ROWS; r++)
	{
		for ( c = 0; c < COLS; c++)
		{
			hall[r][c].exists = 0;
			if(c < (int)strlen(rows[r]) && toupper(rows[r][c]) == 'S')
			{
				hall[r][c].exists = 1;
			}
			hall[r][c].category = category_of_row(r);
			hall[r][c].price = category_prices[hall[r][c].category];
			hall[r][c].booked = 0;
			memset(&hall[r][c].booking, 0, sizeof(struct Booking));
		}
	}
	return used_file;
}

void count_stats(struct Seat hall[][COLS], int *booked, int *total, int *revenue)
{
	int r, c;
	*booked = 0;
	*total = 0;
	*revenue = 0;

	for ( r = 0; r < ROWS; r++)
	{
		for ( c = 0; c < COLS; c++)
		{
			if(hall[r][c].exists == 1)
			{
				(*total)++;
				if(hall[r][c].booked == 1)
				{
					(*booked)++;
					*revenue = *revenue + hall[r][c].booking.ticket_price;
				}
			}
		}
	}
}

//---------------------------------------- saving and loading bookings ----------------------------------------

void save_bookings(struct Seat hall[][COLS], int next_id)
{
	FILE *fp = fopen("cinema_bookings.txt", "w");
	char name[30];
	int r, c, i;
	struct Seat *s;

	if(fp == NULL)
	{
		strcpy(message, "Warning: could not save bookings to cinema_bookings.txt");
		return;
	}

	fprintf(fp, "%d\n", next_id);
	for ( r = 0; r < ROWS; r++)
	{
		for ( c = 0; c < COLS; c++)
		{
			s = &hall[r][c];
			if(s->exists == 1 && s->booked == 1)
			{
				strcpy(name, s->booking.customer.name);
				for ( i = 0; name[i] != '\0'; i++)
				{
					if(name[i] == ' ')
					{
						name[i] = '_';
					}
				}
				fprintf(fp, "%d %d %d %d %d %s %s\n", r, c, s->booking.id, s->booking.ticket_price,
						s->booking.customer.age, s->booking.customer.phone, name);
			}
		}
	}
	fclose(fp);
}

//Returns the number of bookings restored
int load_bookings(struct Seat hall[][COLS], int *next_id)
{
	FILE *fp = fopen("cinema_bookings.txt", "r");
	char name[30], phone[12];
	int r, c, id, price, age, i;
	int restored = 0;
	struct Seat *s;

	if(fp == NULL)
	{
		return 0;
	}

	if(fscanf(fp, "%d", next_id) != 1)
	{
		*next_id = 1001;
		fclose(fp);
		return 0;
	}

	while(fscanf(fp, "%d %d %d %d %d %11s %29s", &r, &c, &id, &price, &age, phone, name) == 7)
	{
		if(r >= 0 && r < ROWS && c >= 0 && c < COLS && hall[r][c].exists == 1)
		{
			for ( i = 0; name[i] != '\0'; i++)
			{
				if(name[i] == '_')
				{
					name[i] = ' ';
				}
			}
			s = &hall[r][c];
			s->booked = 1;
			s->booking.id = id;
			s->booking.ticket_price = price;
			s->booking.customer.age = age;
			strcpy(s->booking.customer.phone, phone);
			strcpy(s->booking.customer.name, name);
			restored++;
		}
	}

	fclose(fp);
	return restored;
}

//---------------------------------------- drawing ----------------------------------------

void draw_hall(struct Seat hall[][COLS], int cur_r, int cur_c)
{
	int r, c, bg, fg;
	struct Seat *s;

	move_to(0, 0);
	paint(C_WHITE);
	printf("  %-76s\n", "============ INTERACTIVE CINEMA SEAT MAPPER ============");
	printf("  %-76s\n", MOVIE_INFO);
	paint(C_CYAN);
	printf("  %-76s\n", "                 ______________ S C R E E N ______________");

	paint(C_GRAY);
	printf("     ");
	for ( c = 0; c < COLS; c++)
	{
		printf("%-4d", c + 1);
	}
	printf("\n");

	for ( r = 0; r < ROWS; r++)
	{
		paint(category_colors[category_of_row(r)]);
		printf("  %c  ", 'A' + r);

		for ( c = 0; c < COLS; c++)
		{
			s = &hall[r][c];

			if(s->exists == 0)
			{
				paint(C_WHITE);
				printf("    ");
			}
			else
			{
				bg = C_BLACK;
				if(r == cur_r && c == cur_c)
				{
					bg = C_YELLOW;
				}

				if(s->booked == 1)
				{
					paint(bg * 16 + C_RED);
					printf("%c%c%c", 219, 219, 219);
				}
				else
				{
					fg = C_GREEN;
					if(bg == C_YELLOW)
					{
						fg = C_BLACK;
					}
					paint(bg * 16 + fg);
					printf("[ ]");
				}
				paint(C_WHITE);
				printf(" ");
			}
		}
		printf("\n");
	}

	//Legend
	paint(C_GREEN);
	printf("  [ ]");
	paint(C_WHITE);
	printf(" Available    ");
	paint(C_RED);
	printf("%c%c%c", 219, 219, 219);
	paint(C_WHITE);
	printf(" Booked    ");
	paint(C_YELLOW * 16 + C_BLACK);
	printf("   ");
	paint(C_WHITE);
	printf(" Cursor %-30s\n", "");

	for ( r = 0; r < 3; r++)
	{
		paint(category_colors[r]);
		printf("  %-9s Rs %-5d", category_names[r], category_prices[r]);
	}
	paint(C_WHITE);
	printf("%-20s\n", "");

	paint(C_GRAY);
	printf("  %-76s\n", "Arrows/WASD: move   B: book   C: cancel   F: find customer   Q: quit");
	paint(C_WHITE);
}

//Info panel for the seat under the cursor
void show_info(struct Seat *s, int r, int c)
{
	char line[120];

	move_to(0, PANEL_ROW);

	paint(category_colors[s->category]);
	sprintf(line, "  Seat %c%d   |   %s   |   Rs %d", 'A' + r, c + 1, category_names[s->category], s->price);
	printf("%-78s\n", line);

	if(s->booked == 0)
	{
		paint(C_GREEN);
		printf("%-78s\n", "  Status   : AVAILABLE - press B to book this seat");
		paint(C_WHITE);
		printf("%-78s\n", "");
		printf("%-78s\n", "");
		printf("%-78s\n", "");
	}
	else
	{
		paint(C_RED);
		printf("%-78s\n", "  Status   : BOOKED");
		paint(C_WHITE);

		sprintf(line, "  Booking  : #%d      Customer : %s", s->booking.id, s->booking.customer.name);
		printf("%-78s\n", line);

		sprintf(line, "  Phone    : %s      Age : %d", s->booking.customer.phone, s->booking.customer.age);
		printf("%-78s\n", line);

		if(s->booking.ticket_price < s->price)
		{
			sprintf(line, "  Paid     : Rs %d  (discount applied)", s->booking.ticket_price);
		}
		else
		{
			sprintf(line, "  Paid     : Rs %d", s->booking.ticket_price);
		}
		printf("%-78s\n", line);
	}
	paint(C_WHITE);
}

//Color changes with how full the hall is
void show_summary(struct Seat hall[][COLS])
{
	int booked, total, revenue, percent, color;
	char line[120];

	count_stats(hall, &booked, &total, &revenue);

	percent = 0;
	if(total > 0)
	{
		percent = booked * 100 / total;
	}

	if(percent >= 80)
	{
		color = C_RED;
	}
	else if(percent >= 50)
	{
		color = C_YELLOW;
	}
	else
	{
		color = C_GREEN;
	}

	move_to(0, SUMMARY_ROW);
	paint(color);
	sprintf(line, "  Booked: %d / %d seats (%d%%)      Revenue: Rs %d", booked, total, percent, revenue);
	printf("%-78s\n", line);
	paint(C_WHITE);
}

void show_message()
{
	move_to(0, MESSAGE_ROW);
	paint(C_YELLOW);
	printf("  %-76s", message);
	paint(C_WHITE);
}

//---------------------------------------- prompts ----------------------------------------

void clear_rows(int start, int count)
{
	int i;
	paint(C_WHITE);
	for ( i = 0; i < count; i++)
	{
		move_to(0, start + i);
		printf("%-78s", "");
	}
}

void prompt_line(int row, char *label, char *buf, int size)
{
	move_to(0, row);
	paint(C_WHITE);
	printf("%-78s", "");
	move_to(2, row);
	printf("%s", label);
	read_line(buf, size);
}

void show_error(char *text)
{
	move_to(2, ERROR_ROW);
	paint(C_RED);
	printf("%-70s", text);
	paint(C_WHITE);
}

//---------------------------------------- actions ----------------------------------------

//Moves the cursor to the next real seat, skipping aisle gaps
void move_cursor(struct Seat hall[][COLS], int *r, int *c, int dr, int dc)
{
	int nr, nc, offset;

	if(dr == 0)
	{
		nc = *c + dc;
		while(nc >= 0 && nc < COLS && hall[*r][nc].exists == 0)
		{
			nc = nc + dc;
		}
		if(nc >= 0 && nc < COLS)
		{
			*c = nc;
		}
	}
	else
	{
		nr = *r + dr;
		while(nr >= 0 && nr < ROWS)
		{
			for ( offset = 0; offset < COLS; offset++)
			{
				if(*c + offset < COLS && hall[nr][*c + offset].exists == 1)
				{
					*r = nr;
					*c = *c + offset;
					return;
				}
				if(*c - offset >= 0 && hall[nr][*c - offset].exists == 1)
				{
					*r = nr;
					*c = *c - offset;
					return;
				}
			}
			nr = nr + dr;
		}
	}
}

//Returns 1 if the seat was booked
int book_seat(struct Seat *s, int r, int c, int *next_id)
{
	char name[50], phone[50], age_text[50];
	int age, valid, price;

	clear_rows(PANEL_ROW, 6);
	show_cursor(1);

	move_to(2, PANEL_ROW);
	paint(C_YELLOW);
	printf("BOOKING SEAT %c%d  (%s, Rs %d)", 'A' + r, c + 1, category_names[s->category], s->price);
	paint(C_WHITE);

	do
	{
		prompt_line(PANEL_ROW + 1, "Customer name : ", name, 50);
		valid = valid_name(name);
		if(valid == 0)
		{
			show_error("Name must be 2-29 characters, alphabets and spaces only!");
		}
	} while(valid == 0);
	show_error("");
	capitalize_name(name);

	do
	{
		prompt_line(PANEL_ROW + 2, "Phone (11 digits) : ", phone, 50);
		valid = (strlen(phone) == 11 && all_digits(phone));
		if(valid == 0)
		{
			show_error("Phone number must be exactly 11 digits!");
		}
	} while(valid == 0);
	show_error("");

	do
	{
		prompt_line(PANEL_ROW + 3, "Age (1-99) : ", age_text, 50);
		valid = 0;
		age = 0;
		if(all_digits(age_text) && strlen(age_text) <= 2)
		{
			age = atoi(age_text);
			if(age >= 1)
			{
				valid = 1;
			}
		}
		if(valid == 0)
		{
			show_error("Age must be a number from 1 to 99!");
		}
	} while(valid == 0);
	show_error("");

	//Children under 12 pay half, seniors from 60 get 20% off
	price = s->price;
	if(age < 12)
	{
		price = price * 50 / 100;
	}
	else if(age >= 60)
	{
		price = price * 80 / 100;
	}

	s->booked = 1;
	s->booking.id = *next_id;
	(*next_id)++;
	s->booking.ticket_price = price;
	s->booking.customer.age = age;
	strcpy(s->booking.customer.name, name);
	strcpy(s->booking.customer.phone, phone);

	show_cursor(0);
	sprintf(message, "Seat %c%d booked for %s. Ticket #%d, Rs %d.", 'A' + r, c + 1, name, s->booking.id, price);
	return 1;
}

//Returns 1 if the booking was cancelled
int cancel_seat(struct Seat *s, int r, int c)
{
	char answer;

	clear_rows(PANEL_ROW, 6);
	move_to(2, PANEL_ROW);
	paint(C_YELLOW);
	printf("Cancel ticket #%d of %s on seat %c%d? Rs %d will be refunded. (Y/N): ", s->booking.id,
		   s->booking.customer.name, 'A' + r, c + 1, s->booking.ticket_price);
	paint(C_WHITE);

	answer = toupper(getch());
	if(answer != 'Y')
	{
		strcpy(message, "Cancellation aborted.");
		return 0;
	}

	sprintf(message, "Ticket #%d cancelled. Rs %d refunded to %s.", s->booking.id, s->booking.ticket_price, s->booking.customer.name);
	s->booked = 0;
	memset(&s->booking, 0, sizeof(struct Booking));
	return 1;
}

//Searches by booking ID (digits) or by partial customer name and moves the cursor there
void find_customer(struct Seat hall[][COLS], int *cur_r, int *cur_c)
{
	char text[50];
	int r, c, id;
	int is_id;

	clear_rows(PANEL_ROW, 6);
	show_cursor(1);
	prompt_line(PANEL_ROW, "Enter customer name (or part of it) or booking ID: ", text, 50);
	show_cursor(0);

	if(strlen(text) == 0)
	{
		strcpy(message, "Nothing entered.");
		return;
	}

	is_id = all_digits(text);
	id = atoi(text);

	for ( r = 0; r < ROWS; r++)
	{
		for ( c = 0; c < COLS; c++)
		{
			if(hall[r][c].exists == 1 && hall[r][c].booked == 1)
			{
				if((is_id == 1 && hall[r][c].booking.id == id) ||
				   (is_id == 0 && contains_text(hall[r][c].booking.customer.name, text)))
				{
					*cur_r = r;
					*cur_c = c;
					sprintf(message, "Found %s on seat %c%d.", hall[r][c].booking.customer.name, 'A' + r, c + 1);
					return;
				}
			}
		}
	}
	sprintf(message, "No booking matches \"%s\".", text);
}

int main()
{
	struct Seat hall[ROWS][COLS];
	struct Seat *seat;
	int cur_r = 0, cur_c = 0;
	int next_id = 1001;
	int running = 1;
	int key, r, c, restored, from_file;

	from_file = load_layout(hall);
	restored = load_bookings(hall, &next_id);

	//Start the cursor on the first real seat
	for ( r = ROWS - 1; r >= 0; r--)
	{
		for ( c = COLS - 1; c >= 0; c--)
		{
			if(hall[r][c].exists == 1)
			{
				cur_r = r;
				cur_c = c;
			}
		}
	}

	if(from_file == 1)
	{
		sprintf(message, "Layout loaded from layout.txt. %d booking(s) restored.", restored);
	}
	else
	{
		sprintf(message, "Built-in layout loaded. %d booking(s) restored.", restored);
	}

	system("cls");
	show_cursor(0);

	while(running == 1)
	{
		seat = &hall[cur_r][cur_c];
		draw_hall(hall, cur_r, cur_c);
		show_info(seat, cur_r, cur_c);
		show_summary(hall);
		show_message();

		key = getch();
		message[0] = '\0';

		if(key == 0 || key == 224)
		{
			key = getch();
			if(key == 72)
			{
				move_cursor(hall, &cur_r, &cur_c, -1, 0);
			}
			else if(key == 80)
			{
				move_cursor(hall, &cur_r, &cur_c, 1, 0);
			}
			else if(key == 75)
			{
				move_cursor(hall, &cur_r, &cur_c, 0, -1);
			}
			else if(key == 77)
			{
				move_cursor(hall, &cur_r, &cur_c, 0, 1);
			}
		}
		else
		{
			key = toupper(key);

			if(key == 'W')
			{
				move_cursor(hall, &cur_r, &cur_c, -1, 0);
			}
			else if(key == 'S')
			{
				move_cursor(hall, &cur_r, &cur_c, 1, 0);
			}
			else if(key == 'A')
			{
				move_cursor(hall, &cur_r, &cur_c, 0, -1);
			}
			else if(key == 'D')
			{
				move_cursor(hall, &cur_r, &cur_c, 0, 1);
			}
			else if(key == 'B')
			{
				if(seat->booked == 0)
				{
					if(book_seat(seat, cur_r, cur_c, &next_id) == 1)
					{
						save_bookings(hall, next_id);
					}
				}
				else
				{
					strcpy(message, "This seat is already booked! Press C to cancel it.");
				}
			}
			else if(key == 'C')
			{
				if(seat->booked == 1)
				{
					if(cancel_seat(seat, cur_r, cur_c) == 1)
					{
						save_bookings(hall, next_id);
					}
				}
				else
				{
					strcpy(message, "This seat has no booking to cancel.");
				}
			}
			else if(key == 'F')
			{
				find_customer(hall, &cur_r, &cur_c);
			}
			else if(key == 'Q' || key == 27)
			{
				running = 0;
			}
		}
	}

	save_bookings(hall, next_id);
	show_cursor(1);
	paint(C_WHITE);
	system("cls");
	printf("\n\tBookings saved to cinema_bookings.txt. Enjoy the movie!\n");
	return 0;
}
